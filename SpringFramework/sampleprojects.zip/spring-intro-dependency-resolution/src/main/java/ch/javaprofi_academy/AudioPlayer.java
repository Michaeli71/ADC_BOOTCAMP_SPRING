package ch.javaprofi_academy;

public interface AudioPlayer {
}
