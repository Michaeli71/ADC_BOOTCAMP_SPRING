package ch.javaprofi_academy;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

//@Primary
@Component("androidAuto")
//@Component
public class AndroidAuto implements AudioPlayer {
}
