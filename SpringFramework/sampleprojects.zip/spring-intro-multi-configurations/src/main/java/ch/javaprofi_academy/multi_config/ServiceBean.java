package ch.javaprofi_academy.multi_config;

public class ServiceBean {


}