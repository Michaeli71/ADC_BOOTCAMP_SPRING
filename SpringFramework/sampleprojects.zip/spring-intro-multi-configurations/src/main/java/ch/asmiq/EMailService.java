package ch.asmiq;

public class EMailService {

	@Override
	public String toString() {
		return "PAPSTART EMailService []";
	}
}
