package ch.asmiq.demo;

public class UserPreferences {
	private String userId;
	private int audioLevel;
	private boolean tooltip;
	private String language;

	public UserPreferences() {
	}

	public UserPreferences(String userId, int audioLevel, boolean tooltip, String language) {

		this.userId = userId;
		this.audioLevel = audioLevel;
		this.tooltip = tooltip;
		this.language = language;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getAudioLevel() {
		return audioLevel;
	}

	public void setAudioLevel(int audioLevel) {
		this.audioLevel = audioLevel;
	}

	public boolean isTooltip() {
		return tooltip;
	}

	public void setTooltip(boolean tooltip) {
		this.tooltip = tooltip;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	@Override
	public String toString() {
		return "UserPreferences [userId=" + userId + ", audioLevel=" + audioLevel + ", tooltip=" + tooltip
				+ ", language=" + language + "]";
	}

}
