package ch.asmiq.demo;

import ch.asmiq.tomcat.TomcatStarter;

public class ExampleApp {

	public static void main(final String[] args) throws InterruptedException {

		TomcatStarter.startTomcat();
	}	
}