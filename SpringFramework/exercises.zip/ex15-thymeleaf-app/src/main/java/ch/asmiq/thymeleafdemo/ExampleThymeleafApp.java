package ch.asmiq.thymeleafdemo;

import ch.asmiq.tomcat.TomcatStarter;

public class ExampleThymeleafApp {

	public static void main(final String[] args) throws InterruptedException {
		
		TomcatStarter.startTomcat();
	}
}