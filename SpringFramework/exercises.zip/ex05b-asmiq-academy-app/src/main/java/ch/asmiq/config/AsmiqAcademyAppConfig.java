package ch.asmiq.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import ch.asmiq.interfaces.NotificationService;
import ch.asmiq.service.EmailService;
import ch.asmiq.service.SmsService;

// Variante 1: Configuration mit @Primary @Bean
@Configuration
public class AsmiqAcademyAppConfig {
 
	//@Primary
	@Bean
	public NotificationService smsService() {
		return new SmsService();
	}
	
	@Primary
	@Bean
	public NotificationService emailService() {
		return new EmailService();
	}
	
	/*
	@Primary
	@Bean
	public CourseService courseService() {
		return new LiveCourseService();
	}
	*/
}



