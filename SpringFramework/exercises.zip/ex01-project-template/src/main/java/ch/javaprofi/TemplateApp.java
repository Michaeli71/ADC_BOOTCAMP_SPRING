package ch.javaprofi;

import java.util.logging.Logger;

public class TemplateApp {

	private static final Logger LOG = Logger.getLogger(TemplateApp.class.getName());

	public static void main(String[] args) {
		LOG.info("It works");
	}
}
