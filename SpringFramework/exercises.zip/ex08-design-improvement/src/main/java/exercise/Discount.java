package exercise;

public class Discount {

	public double apply(Pizza pizza) {
		return 0;
	}

}
