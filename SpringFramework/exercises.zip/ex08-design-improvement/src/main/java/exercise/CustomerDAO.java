package exercise;

public class CustomerDAO {

	public Customer findById(long customerId) {
		
		return null;
	}

}
