package step2;

import exercise.Pizza;

public interface DiscountStrategy {
	double apply(final Pizza pizza);
}
