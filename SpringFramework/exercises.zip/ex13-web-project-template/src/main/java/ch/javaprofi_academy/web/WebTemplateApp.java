package ch.javaprofi_academy.web;

import ch.javaprofi_academy.web.tomcat.TomcatStarter;

public class WebTemplateApp {

	public static void main(String[] args) {
		TomcatStarter.startTomcat();
	}	
}
