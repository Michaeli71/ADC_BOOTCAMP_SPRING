package ch.javaprofi_academy.web.controller;

public class GreetingController {

	public String sayHello() {
		
		return "Hi REST! Spring Workshop";
	}
}
