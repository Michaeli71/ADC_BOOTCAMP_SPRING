package com.example.demo.entities;

public enum BikeType {
	PLAIN, CITYRACER, RACING, MOUNTAIN
}
