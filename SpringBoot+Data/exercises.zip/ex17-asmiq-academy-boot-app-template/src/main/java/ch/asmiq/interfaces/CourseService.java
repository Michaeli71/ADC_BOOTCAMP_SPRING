package ch.asmiq.interfaces;

import java.util.List;

import ch.asmiq.model.Course;

public interface CourseService {

	List<Course> getCourses();

}
