package app.controller.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import app.model.Person;

@Repository
public interface PersonRepository extends CrudRepository<Person, Long>
{
	List<Person> findByNationality(String nationality);

	List<Person> findByAgeGreaterThan(Integer age);

}
