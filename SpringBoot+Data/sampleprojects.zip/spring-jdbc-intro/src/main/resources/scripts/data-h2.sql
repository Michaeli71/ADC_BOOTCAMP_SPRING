insert into EMPLOYEE (id, name, salary) values
(1, 'Vlad',  12345.0),
(2,'Oksi', 23456.0),
(3,'Vadim', 34567.0);