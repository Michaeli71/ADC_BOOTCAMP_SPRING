package springjdbc.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import springjdbc.dao.mapper.EmployeeRowMapper;
import springjdbc.domain.Employee;

public class EmployeeDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int saveEmployee(Employee e) {
		String sql = "insert into employee values('" + e.getId() + "','" + e.getName() + "','" + e.getSalary() + "')";
		return jdbcTemplate.update(sql);
	}

	public int updateEmployee(Employee e) {
		String sql = "update employee set name='" + e.getName() + "',salary='" + e.getSalary() + "' where id='"
				+ e.getId() + "' ";
		return jdbcTemplate.update(sql);
	}

	public int deleteEmployee(Employee e) {
		String sql = "delete from employee where id='" + e.getId() + "' ";
		return jdbcTemplate.update(sql);
	}

	public int getEmployeeCount() {
		String sql = "select count(*) from employee";
		return jdbcTemplate.queryForObject(sql, Integer.class, new Object[] {});
	}
	

	// Erweiterungen
	public Employee getEmployeeById(int id) {
		// Fieser Fehler ...
		//String sql = "select * from employee where id = " + id;
		String sql = "select * from employee where id = ?";
		return jdbcTemplate.queryForObject(sql, new EmployeeRowMapper(), new Object[] { id });
	}

	
	public List<Employee> getAllEmployees() {
		String sql = "select * from employee";
		var a = 10;
		return jdbcTemplate.query(sql, new EmployeeRowMapper());
	}
}