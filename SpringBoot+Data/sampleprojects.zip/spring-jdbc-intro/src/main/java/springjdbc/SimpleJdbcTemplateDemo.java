package springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import springjdbc.dao.EmployeeDao;
import springjdbc.domain.Employee;

public class SimpleJdbcTemplateDemo {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

	    // schema init programmatisch
		/*
		DataSource dataSource = (DataSource) ctx.getBean("ds");
	    Resource initSchema = new ClassPathResource("scripts/schema.sql");
	    Resource initData = new ClassPathResource("scripts/data-h2.sql");
	    DatabasePopulator databasePopulator = new ResourceDatabasePopulator(initSchema, initData);
	    DatabasePopulatorUtils.execute(databasePopulator, dataSource);
	    */
		

		EmployeeDao dao = (EmployeeDao) ctx.getBean("employeeDao");
		
		System.out.println("employee count: " + dao.getEmployeeCount());
		
		int status = dao.saveEmployee(new Employee(4711, "Michael", 12345.0f));
		System.out.println(status);
		
		System.out.println("employee count: " + dao.getEmployeeCount());
		
		// Erweiterungen
		System.out.println(dao.getAllEmployees());
		System.out.println(dao.getEmployeeById(1));
		System.out.println(dao.getEmployeeById(4711));	
	}
}