insert into people (id, first_name, last_name, age) values
(1, 'Michael', 'Inden', 50),
(2, 'Tim', 'Boetzmeyer', 50),
(3, 'Heinz', 'Mustermann', 32),
(4, 'James', 'Bond', 44);