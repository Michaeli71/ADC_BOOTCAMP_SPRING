package com.example.demo.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.example.demo.domain.CarDto;
import com.example.demo.entities.Car;
import com.example.demo.entities.CarType;

public class CarMapperTest {

	@Test
	public void shouldMapCarToDto() {
		// given
		Car car = new Car("FORD", 5, CarType.PICKUP);

		// when
		CarDto carDto = CarMapper.INSTANCE.toDto(car);

		// then
		assertNotNull(carDto);
		assertEquals("FORD", carDto.getMake());
		assertEquals(5, carDto.getSeatCount());
		assertEquals("PICKUP", carDto.getType());
	}
	
	@Test
	public void shouldMapDtoToCar() {
		// given
		CarDto carDto = new CarDto("VW", 7, "SUV");

		// when
		Car car = CarMapper.INSTANCE.toCar(carDto);

		// then
		assertNotNull(carDto);
		assertEquals("VW", car.getMake());
		assertEquals(7, car.getNumberOfSeats());
		assertEquals(CarType.SUV, car.getType());
	}
}
