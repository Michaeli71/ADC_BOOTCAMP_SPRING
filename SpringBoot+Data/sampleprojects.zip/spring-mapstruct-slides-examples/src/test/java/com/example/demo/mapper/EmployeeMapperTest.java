package com.example.demo.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.example.demo.domain.EmployeeDTO;
import com.example.demo.entities.Employee;

public class EmployeeMapperTest {
	
	private EmployeeMapper mapper = Mappers.getMapper(EmployeeMapper.class);

	@Test
	public void givenEmployeeDTOwithDiffNametoEmployee_whenMaps_thenCorrect() {
	    EmployeeDTO dto = new EmployeeDTO();
	    dto.setEmployeeId(1);
	    dto.setEmployeeName("John");
	
	    Employee entity = mapper.employeeDTOtoEmployee(dto);
	
	    assertEquals(dto.getEmployeeId(), entity.getId());
	    assertEquals(dto.getEmployeeName(), entity.getName());
	}
}

