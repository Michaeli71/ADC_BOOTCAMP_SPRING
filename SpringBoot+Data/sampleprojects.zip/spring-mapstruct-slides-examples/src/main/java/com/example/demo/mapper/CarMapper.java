package com.example.demo.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.example.demo.domain.CarDto;
import com.example.demo.entities.Car;

@Mapper 
public interface CarMapper {

    CarMapper INSTANCE = Mappers.getMapper( CarMapper.class ); 

    @Mapping(source = "numberOfSeats", target = "seatCount")
    CarDto toDto(Car car);
    
    @Mapping(source = "seatCount", target = "numberOfSeats")
    Car toCar(CarDto dto); 
}

