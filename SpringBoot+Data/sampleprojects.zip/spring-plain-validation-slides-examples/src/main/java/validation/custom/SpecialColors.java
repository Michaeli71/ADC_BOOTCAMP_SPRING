package validation.custom;

public enum SpecialColors {
	RED, GREEN, BLUE
}
