package com.example.demo.domain;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

public class Input {

	@Min(1)
	@Max(10)
	private int numberBetweenOneAndTen;

	@Pattern(regexp = "^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$")
	private String ipAddress;

	public Input(@Min(1) @Max(10) int numberBetweenOneAndTen,
			@Pattern(regexp = "^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$") String ipAddress) {
		this.numberBetweenOneAndTen = numberBetweenOneAndTen;
		this.ipAddress = ipAddress;
	}

	public int getNumberBetweenOneAndTen() {
		return numberBetweenOneAndTen;
	}

	public void setNumberBetweenOneAndTen(int numberBetweenOneAndTen) {
		this.numberBetweenOneAndTen = numberBetweenOneAndTen;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	

}
