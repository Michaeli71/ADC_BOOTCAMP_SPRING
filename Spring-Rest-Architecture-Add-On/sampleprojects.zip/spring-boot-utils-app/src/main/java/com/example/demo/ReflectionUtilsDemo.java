package com.example.demo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.springframework.beans.BeanUtils;
import org.springframework.util.ReflectionUtils;

import com.example.demo.domain.Employee;
import com.example.demo.domain.Student;

public class ReflectionUtilsDemo {
	
	public static void main(String[] args) // throws IllegalAccessException, IllegalArgumentException, InvocationTargetException 
	{			
		Student student = new Student();

	    Field nameField1 = ReflectionUtils.findField(Student.class, "name");
		ReflectionUtils.makeAccessible(nameField1);
		ReflectionUtils.setField(nameField1, student, "Peter");
	    
	    System.out.println(student);

	    //
	    Employee employee = new Employee();	   
	    setField(employee, "id", 1);
	    System.out.println(employee);
	    
	    Method getIdMethod = ReflectionUtils.findMethod(employee.getClass(), "getId");
	    //System.out.println(getIdMethod.invoke(employee, null));
	    System.out.println(ReflectionUtils.invokeMethod(getIdMethod, employee));	 
	    
	    Method setNameMethod = ReflectionUtils.findMethod(employee.getClass(), "setName", new Class[] {String.class} );
	    ReflectionUtils.invokeMethod(setNameMethod, employee, "Michael");
	    System.out.println(employee);
	    
	    
	    //
	    Employee src = new Employee();	   
	    src.setName("freddie");
		src.setId(15);

		Employee dest = new Employee();	 
		ReflectionUtils.shallowCopyFieldState(src, dest);
		System.out.println(dest);
		
		// Bean Utils besser:
		Employee dest2 = new Employee();
		BeanUtils.copyProperties(src, dest2);
		System.out.println(dest2);
	

	}

	private static void setField(Object obj, String fieldName, Object fieldValue) {
		Field nameField = ReflectionUtils.findField(obj.getClass(), fieldName);
	    ReflectionUtils.makeAccessible(nameField);
	    ReflectionUtils.setField(nameField, obj, fieldValue);
	}
}
