package productapp.services;

import java.util.List;

import productapp.entities.Product;

public interface IProductService {
	List<Product> findAll();
	
	public Product findById(long id) ;
	
	Product create(Product product);

	void deleteById(long id); 	
}