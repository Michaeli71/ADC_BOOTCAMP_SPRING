package aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

import aop.aopdemo.Fibonacci;

@Configuration
@ComponentScan
@EnableAspectJAutoProxy
public class FibonacciAopExampleApp {
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(FibonacciAopExampleApp.class);
		if (args.length > 0) {
			int n = Integer.parseInt(args[0]);
			Fibonacci fibonacci = ctx.getBean(Fibonacci.class);
			System.out.println("fibonacci( " + n + " ) = " + fibonacci.calc(n));
		}
	}
}