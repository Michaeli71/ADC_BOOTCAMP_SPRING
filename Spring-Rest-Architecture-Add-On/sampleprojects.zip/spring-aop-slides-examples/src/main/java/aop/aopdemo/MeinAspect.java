package aop.aopdemo;

import java.util.Arrays;
import org.aspectj.lang.*;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MeinAspect
{
   @Pointcut( "execution( * Fibonacci.*(..) )" )
   public void meinPointcut() {}

   @Before( "meinPointcut()" )
   public void logBefore( JoinPoint jp ) {
      System.out.println( "@Before:       " + jp );
   }

   @Around( "meinPointcut()" )
   public Object logAround( ProceedingJoinPoint jp ) throws Throwable {
      System.out.println( "\n@Around-Start, Argumente: " + Arrays.asList( jp.getArgs() ) );
      Object obj = jp.proceed();
      System.out.println( "@Around-Ende,  Ergebnis:  " + obj );
      return obj;
   }

   @After( "meinPointcut()" )
   public void logAfter( JoinPoint jp ) {
      System.out.println( "@After:        " + jp + "\n" );
   }
}