package aop;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import aop.domain.Operation;

public class AppContextAopExampleApp {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Operation e = (Operation) context.getBean("opBean");
		System.out.println("calling msg...");
		e.msg();
		System.out.println("calling m...");
		e.m();
		System.out.println("calling k...");
		e.k();

		System.out.println("calling validate...");
		try {
			e.validate(19);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		System.out.println("calling validate again...");
	}
}