package bookapp.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import bookapp.entities.Book;

@Service
public class BookService {

	// TODO: add Repository
	List<Book> bookStore = new ArrayList<>();
	{
		bookStore.addAll(List.of(new Book(1, "Java Challenge", "Michael Inden", LocalDate.of(2020, 8, 26), "1122334"),
				new Book(11, "Python Challenge", "Michael Inden", LocalDate.of(2021, 2, 8), "32332")));
	}

	public void deleteById(long id) {
		ensureIdIsValid(id);
		
		Book toBeDeleted = findById(id);
		bookStore.remove(toBeDeleted);
	}

	public List<Book> findAll() {
		return bookStore;
	}

	public Book findById(long id) {
		ensureIdIsValid(id);

		return bookStore.stream().
				         filter(book -> book.getId() == id).
				         findFirst().get();
	}

	public Book create(Book resource) {
		bookStore.add(resource);
		return resource;
	}

	public void update(long id, Book other) {
		ensureIdIsValid(id);

		Book toBeUpdated = findById(id);
		BeanUtils.copyProperties(other, toBeUpdated, "id");
	}

	private void ensureIdIsValid(long id) {
		if (id < 0)
			throw new IllegalArgumentException();
		
		if (bookStore.stream().noneMatch(book -> book.getId() == id))
			throw new IllegalArgumentException();
	}
}
