package user.service;

public class UserNotFoundException extends IllegalArgumentException {

	public UserNotFoundException() {
		super();
	}

	public UserNotFoundException(String s) {
		super(s);
	}
}
