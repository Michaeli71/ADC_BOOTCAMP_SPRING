package user.controllers;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ObjectNode;

import user.entities.User;
import user.service.UserNotFoundException;
import user.service.UserService;

/*
    /create?email=[email]&name=[name]: create a new user with an auto-generated id and email and name as passed values.
    /delete?id=[id]: delete the user with the passed id.
    /get-by-email?email=[email]: retrieve the id for the user with the given email address.
    /update?id=[id]&email=[email]&name=[name]: update the email and the name for the user identified by the given id.
 */

//http://localhost:8080/users/create?email=mehl&name=Mic

//=>

//curl -X POST -H "Content-Type: application/json" http://localhost:8080/users/ -d '{ "email" : "E-MAIL", "name" : "Micha" }'


@RestController
@RequestMapping("users")
public class UserController {

	private static final Logger log = LoggerFactory.getLogger(UserController.class);
	
	@Autowired	
	private UserService userService;
	
	@RequestMapping("")
	public List<User> getAll() {

		return userService.getAll();
	}

	@PostMapping
	// Nicht möglich:
	//public String create(@RequestBody String email, @RequestBody String name) {
	public String create(@RequestBody Map<String,String> json) {
	// Variante: public String create(@RequestBody ObjectNode json) {
		String email = json.get("email");
		String name = json.get("name");
		
		User newUser = userService.createUser(email, name);
		
		return String.valueOf(newUser.getId());
	}
	
	public String createV2(@RequestBody Map<String,String> json) {
	// Variante: public String create(@RequestBody ObjectNode json) {
		String email = json.get("email");
		String name = json.get("name");
		
		User newUser = userService.createUser(new User(email, name));
		
		return String.valueOf(newUser.getId());
	}

	// Bevorzugte Variante
	public String createV3(@Valid @RequestBody User user) {
		
		User newUser = userService.createUser(user);
		
		return String.valueOf(newUser.getId());
	}
	
	@DeleteMapping(value = "/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable long id) {
		userService.deleteById(id);
	}

	// curl "localhost:8080/users/get-by-email?email=mail@mike.de"
	@RequestMapping("/get-by-email")
	public String getByEmail(String email) {
		return userService.getByEmail(email);
	}

	
	@RequestMapping(value = "/{id}")
	public User getById(@PathVariable long id) {
		return userService.getById(id);
	}
	
	@PutMapping(value = "/{id}")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public String updateUser(@PathVariable long id, @RequestBody ObjectNode json) {

		String email = json.get("email").asText();
		String name = json.get("name").asText();

		return userService.updateUser(id, email, name);
	}
	
	
	
	@ExceptionHandler
	void handleIllegalArgumentException(IllegalArgumentException ex, HttpServletResponse response) throws IOException {
		log.warn(ex.getMessage());
		response.sendError(HttpStatus.BAD_REQUEST.value());
	}
	
	@ExceptionHandler
	void handleUserNotFoundException(UserNotFoundException ex, HttpServletResponse response) throws IOException {
		log.warn(ex.getMessage());
		response.sendError(HttpStatus.NOT_FOUND.value());
	}
	
	@ExceptionHandler
	void handleConstraintViolationException(ConstraintViolationException ex, HttpServletResponse response) throws IOException {

		log.warn(ex.getMessage() + " due to " + ex.getConstraintViolations());
		response.sendError(HttpStatus.UNPROCESSABLE_ENTITY.value());
	}
}