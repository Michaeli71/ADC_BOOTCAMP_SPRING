package productclientapp;

import java.util.List;

import org.springframework.web.client.RestTemplate;

import productclientapp.entities.Product;

public class StandaloneRestClientExample {

	public static final String SERVER_URI = "http://localhost:8080/products";

	public static void main(String args[]) {

		RestTemplate restTemplate = new RestTemplate();

		getAllProducts(restTemplate);
		System.out.println("*****");
		getProduct100(restTemplate);
		System.out.println("*****");
		Product product = new Product(4711, "IPAD", "PRO", 10101, 12345);
		createProduct(restTemplate, product);
		System.out.println("*****");
		getAllProducts(restTemplate);
		System.out.println("*****");
	}

	public static void createProduct(RestTemplate restTemplate, Product product) {
		// TODO		
	}
	
	@SuppressWarnings("unchecked")
	public static List<Product> getAllProducts(RestTemplate restTemplate) {
		// TODO
		return null;
	}

	public static Product getProduct100(RestTemplate restTemplate) {
		// TODO
		return null;
	}
}