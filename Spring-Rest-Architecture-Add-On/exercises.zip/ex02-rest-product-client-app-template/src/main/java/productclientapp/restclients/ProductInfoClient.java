package productclientapp.restclients;

import org.springframework.stereotype.Component;

@Component
public class ProductInfoClient {

	public static final String SERVER_URI = "http://localhost:8080/products";

// 	TODO
}