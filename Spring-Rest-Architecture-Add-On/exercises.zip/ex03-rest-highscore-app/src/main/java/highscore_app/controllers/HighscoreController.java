package highscore_app.controllers;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import highscore_app.entities.Highscore;
import highscore_app.services.HighscoreService;

/*
•	POST „Highscore“
•	GET /highscores
•	GET /highscores/top/<n>
•	GET /highscores/byPerson/<name>
•	GET /highscores/byLocalDate/<localdate>
•	DELETE /highscores/<n>
•	DELETE /highscores/of/<name>
•	DELETE /highscores/on/<localdate >
 */

// curl localhost:9999/highscores 

// curl -X DELETE localhost:9999/highscores/1

// curl localhost:9999/highscores/byPerson/Michael

// curl -X POST -H "Content-Type: application/json" http://localhost:9999/highscores -d '{ "name" : "MALAD", "points" : "7654321", "level" : "1234" }'


@RestController
@RequestMapping("/highscores")
public class HighscoreController {

	private static final Logger log = LoggerFactory.getLogger(HighscoreController.class);
	
	@Autowired	
	private HighscoreService highscoreService;
	
	@RequestMapping("")
	public List<Highscore> getAll() {

		return highscoreService.getAll();
	}

	@RequestMapping("/top5")
	public List<Highscore> getTop5() {

		return highscoreService.getTop5();
	}
	
	@RequestMapping("/top/{n}")
	public List<Highscore> getTopN(@PathVariable int n) {

		return highscoreService.getTopN(n);
	}
	
	@PostMapping
	//public String create(@RequestBody String email, @RequestBody String name) {
	public String create(@RequestBody Map<String,String> json) {		
	//public String create(@RequestBody ObjectNode json) {
		String name = json.get("name");
		int points = Integer.parseInt(json.get("points"));
		int level = Integer.parseInt(json.get("level")); 
		
		Highscore newHighscore = highscoreService.createHighscore(name, points, level);
		
		return String.valueOf(newHighscore.getId());
	}

	
	@RequestMapping("/byPerson/{name}")
	public List<Highscore> getByPerson(@PathVariable String name) {
		return highscoreService.getByPerson(name);
	}

	@DeleteMapping(value = "/{pos}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable int pos) {
		highscoreService.deleteByPos(pos);
	}

	
	
	
	
	@ExceptionHandler
	void handleIllegalArgumentException(IllegalArgumentException ex, HttpServletResponse response) throws IOException {
		log.warn(ex.getMessage());
		response.sendError(HttpStatus.BAD_REQUEST.value());
	}
	
	@ExceptionHandler
	void handleConstraintViolationException(ConstraintViolationException ex, HttpServletResponse response) throws IOException {

		log.warn(ex.getMessage() + " due to " + ex.getConstraintViolations());
		response.sendError(HttpStatus.UNPROCESSABLE_ENTITY.value());
	}	
	
}
